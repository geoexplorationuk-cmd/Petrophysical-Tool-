import unittest
from config import CONFIG
from modules.petrophysics import evaluate
from modules.rock_physics import calculate
from modules.log_qc import run_qc

class CalculationTests(unittest.TestCase):
    def setUp(self):
        self.rows = [{
            "DEPTH_M": 1500.0, "GR_API": 35.0, "RHOB_GCC": 2.35,
            "NPHI_VV": 0.22, "DTCO_USFT": 75.0, "DTS_USFT": 135.0,
            "RT_OHMM": 20.0, "CALI_IN": 8.6, "PEF_B_E": 2.2
        }]

    def test_petrophysics_bounded(self):
        result = evaluate(self.rows, CONFIG)[0]
        self.assertGreaterEqual(result["VSH_VV"], 0)
        self.assertLessEqual(result["VSH_VV"], 1)
        self.assertGreaterEqual(result["SW_ARCHIE_VV"], 0)
        self.assertLessEqual(result["SW_ARCHIE_VV"], 1)

    def test_rock_physics_positive(self):
        result = calculate(self.rows)[0]
        self.assertGreater(result["VP_M_S"], result["VS_M_S"])
        self.assertGreater(result["BULK_MODULUS_GPA"], 0)

    def test_qc_row_returned(self):
        result, counts = run_qc(self.rows, CONFIG)
        self.assertEqual(len(result), 1)
        self.assertIn(result[0]["QC_STATUS"], ("PASS", "REVIEW", "FAIL"))
        self.assertEqual(sum(counts.values()), 1)

if __name__ == "__main__":
    unittest.main()
