"""Default illustrative parameters. Calibrate for each well / formation."""
CONFIG = {
    "gr_clean_api": 25.0,
    "gr_shale_api": 120.0,
    "matrix_density_gcc": 2.65,
    "fluid_density_gcc": 1.00,
    "shale_porosity_vv": 0.08,
    "archie_a": 1.0,
    "archie_m": 2.0,
    "archie_n": 2.0,
    "formation_water_resistivity_ohmm": 0.08,
    "caliper_bit_size_in": 8.5,
    "caliper_tolerance_in": 1.0,
    "min_dtco_usft": 40.0,
    "max_dtco_usft": 200.0,
    "min_dts_usft": 60.0,
    "max_dts_usft": 350.0,
    "overburden_gradient_mpa_per_km": None,  # calculated from density
    "pore_pressure_gradient_mpa_per_km": 10.0,
    "ucs_vp_intercept_mpa": -20.0,  # illustrative empirical proxy only
    "ucs_vp_slope_mpa_per_kms": 0.035,
    "brine_bulk_modulus_gpa": 2.5,
    "gas_bulk_modulus_gpa": 0.08,
    "brine_density_gcc": 1.05,
    "gas_density_gcc": 0.20,
    "initial_water_saturation": 1.0,
}
