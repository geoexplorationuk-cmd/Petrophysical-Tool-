from .io_utils import safe_float

def gassmann_substitution(rock_rows, pet_rows, cfg):
    """
    Gassmann substitution from a brine-saturated reference to a gas-like fluid.
    Uses Ksat = Kdry + (1-Kdry/K0)^2 /
      [phi/Kf + (1-phi)/K0 - Kdry/K0^2].
    Kdry is back-calculated from the reference saturated modulus.
    """
    out = []
    k0 = cfg["matrix_density_gcc"]  # placeholder replaced below by explicit mineral modulus
    k0 = 37.0  # GPa, illustrative quartz-rich mineral bulk modulus
    kf_initial = cfg["brine_bulk_modulus_gpa"]
    kf_new = cfg["gas_bulk_modulus_gpa"]
    for rock, pet in zip(rock_rows, pet_rows):
        depth = safe_float(rock, "DEPTH_M")
        ksat = safe_float(rock, "BULK_MODULUS_GPA")
        mu = safe_float(rock, "SHEAR_MODULUS_GPA")
        phi = safe_float(pet, "PHIE_VV")
        rho = safe_float(rock, "DENSITY_KG_M3")
        if None in (ksat, mu, phi, rho) or phi <= 0 or phi >= 1:
            out.append({"DEPTH_M": depth, "KDRY_GPA": None, "VP_BRINE_M_S": None,
                        "VP_GAS_M_S": None, "VS_M_S": None, "AI_BRINE": None,
                        "AI_GAS": None, "DELTA_VP_PERCENT": None})
            continue
        # Invert Gassmann equation for Kdry by bisection, constrained to [0, Ksat].
        def forward(kdry, kf):
            den = phi/kf + (1-phi)/k0 - kdry/(k0*k0)
            if den <= 0:
                return None
            return kdry + ((1-kdry/k0)**2)/den
        lo, hi = 0.01, min(ksat, k0*0.999)
        for _ in range(80):
            mid = (lo + hi)/2
            value = forward(mid, kf_initial)
            if value is None or value > ksat:
                hi = mid
            else:
                lo = mid
        kdry = (lo+hi)/2
        ksat_new = forward(kdry, kf_new)
        if ksat_new is None:
            vp_brine = vp_gas = vs = ai_b = ai_g = delta = None
        else:
            # Reference density treated as brine saturated; replace brine density by gas density
            rho_brine = rho
            rho_new = max(500.0, rho_brine - phi *
                          (cfg["brine_density_gcc"] - cfg["gas_density_gcc"]) * 1000.0)
            vp_brine = ((ksat*1e9 + 4/3*mu*1e9)/rho_brine)**0.5
            vp_gas = ((ksat_new*1e9 + 4/3*mu*1e9)/rho_new)**0.5
            vs = (mu*1e9/rho_new)**0.5
            ai_b, ai_g = rho_brine*vp_brine, rho_new*vp_gas
            delta = (vp_gas-vp_brine)/vp_brine*100 if vp_brine else None
        out.append({
            "DEPTH_M": depth, "KDRY_GPA": kdry, "KBRINE_GPA": ksat,
            "KGAS_GPA": ksat_new, "VP_BRINE_M_S": vp_brine,
            "VP_GAS_M_S": vp_gas, "VS_GAS_DENSITY_M_S": vs,
            "AI_BRINE": ai_b, "AI_GAS": ai_g, "DELTA_VP_PERCENT": delta
        })
    return out
