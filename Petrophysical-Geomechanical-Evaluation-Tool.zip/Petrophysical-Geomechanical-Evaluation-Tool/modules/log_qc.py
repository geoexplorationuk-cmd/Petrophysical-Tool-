from .io_utils import safe_float

REQUIRED = ["DEPTH_M", "GR_API", "RHOB_GCC", "NPHI_VV", "DTCO_USFT", "DTS_USFT", "RT_OHMM"]

def run_qc(rows, cfg):
    output = []
    previous_depth = None
    counts = {"PASS": 0, "REVIEW": 0, "FAIL": 0}
    for i, row in enumerate(rows, start=1):
        flags, remarks = [], []
        for key in REQUIRED:
            if safe_float(row, key) is None:
                flags.append("MISSING_" + key)
                remarks.append(key + " missing/non-numeric")
        depth = safe_float(row, "DEPTH_M")
        if depth is not None and previous_depth is not None and depth <= previous_depth:
            flags.append("DEPTH_ORDER")
            remarks.append("Depth is not strictly increasing")
        if depth is not None:
            previous_depth = depth
        checks = [
            ("GR_API", 0, 300), ("RHOB_GCC", 1.5, 3.2),
            ("NPHI_VV", -0.15, 0.8), ("RT_OHMM", 0.01, 1e6)
        ]
        for key, lo, hi in checks:
            val = safe_float(row, key)
            if val is not None and not (lo <= val <= hi):
                flags.append("RANGE_" + key)
                remarks.append(f"{key} outside screening range")
        dtco = safe_float(row, "DTCO_USFT")
        dts = safe_float(row, "DTS_USFT")
        if dtco is not None and not cfg["min_dtco_usft"] <= dtco <= cfg["max_dtco_usft"]:
            flags.append("SONIC_DTCO")
            remarks.append("DTCO outside configured screening range")
        if dts is not None and not cfg["min_dts_usft"] <= dts <= cfg["max_dts_usft"]:
            flags.append("SONIC_DTS")
            remarks.append("DTS outside configured screening range")
        cali = safe_float(row, "CALI_IN")
        if cali is not None and abs(cali - cfg["caliper_bit_size_in"]) > cfg["caliper_tolerance_in"]:
            flags.append("CALIPER")
            remarks.append("Caliper differs from bit size beyond tolerance")
        if any(x.startswith("MISSING_") for x in flags):
            status = "FAIL"
        elif flags:
            status = "REVIEW"
        else:
            status = "PASS"
        counts[status] += 1
        output.append({
            "ROW": i, "DEPTH_M": depth, "QC_STATUS": status,
            "QC_FLAGS": ";".join(flags), "QC_REMARKS": "; ".join(remarks)
        })
    return output, counts
