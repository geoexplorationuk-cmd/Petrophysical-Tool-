from .io_utils import safe_float

def calculate(rows):
    out = []
    for row in rows:
        depth = safe_float(row, "DEPTH_M")
        rhob = safe_float(row, "RHOB_GCC")
        dtco = safe_float(row, "DTCO_USFT")
        dts = safe_float(row, "DTS_USFT")
        vp = 304800.0 / dtco if dtco and dtco > 0 else None
        vs = 304800.0 / dts if dts and dts > 0 else None
        rho = rhob * 1000.0 if rhob is not None else None
        if rho and vp and vs and vp > vs:
            mu_pa = rho * vs**2
            bulk_pa = rho * (vp**2 - (4.0/3.0) * vs**2)
            young_pa = mu_pa * (3*bulk_pa + mu_pa) / (bulk_pa + mu_pa) if bulk_pa + mu_pa else None
            poisson = (vp**2 - 2*vs**2) / (2*(vp**2 - vs**2))
            ai = rho * vp
            out.append({
                "DEPTH_M": depth, "VP_M_S": vp, "VS_M_S": vs,
                "DENSITY_KG_M3": rho, "BULK_MODULUS_GPA": bulk_pa/1e9,
                "SHEAR_MODULUS_GPA": mu_pa/1e9,
                "YOUNG_MODULUS_GPA": young_pa/1e9 if young_pa is not None else None,
                "POISSON_RATIO": poisson, "AI_KG_M2_S": ai
            })
        else:
            out.append({
                "DEPTH_M": depth, "VP_M_S": vp, "VS_M_S": vs,
                "DENSITY_KG_M3": rho, "BULK_MODULUS_GPA": None,
                "SHEAR_MODULUS_GPA": None, "YOUNG_MODULUS_GPA": None,
                "POISSON_RATIO": None, "AI_KG_M2_S": None
            })
    return out
