from .io_utils import safe_float, clamp

def evaluate(rows, cfg):
    out = []
    for row in rows:
        depth = safe_float(row, "DEPTH_M")
        gr = safe_float(row, "GR_API")
        rhob = safe_float(row, "RHOB_GCC")
        nphi = safe_float(row, "NPHI_VV")
        rt = safe_float(row, "RT_OHMM")
        vsh = phid = phie = sw = None
        if gr is not None:
            vsh = clamp((gr - cfg["gr_clean_api"]) /
                        (cfg["gr_shale_api"] - cfg["gr_clean_api"]), 0.0, 1.0)
        if rhob is not None:
            denom = cfg["matrix_density_gcc"] - cfg["fluid_density_gcc"]
            phid = clamp((cfg["matrix_density_gcc"] - rhob) / denom, 0.0, 1.0)
        if phid is not None and vsh is not None:
            phie = clamp(phid - vsh * cfg["shale_porosity_vv"], 0.0, 0.6)
        if phie is not None and rt is not None and phie > 0:
            term = (cfg["archie_a"] * cfg["formation_water_resistivity_ohmm"]) / (
                (phie ** cfg["archie_m"]) * rt)
            sw = clamp(term ** (1.0 / cfg["archie_n"]), 0.0, 1.0)
        if nphi is not None and phid is not None:
            phi_nd = (nphi + phid) / 2.0
        else:
            phi_nd = None
        out.append({
            "DEPTH_M": depth, "VSH_VV": vsh, "PHID_VV": phid,
            "PHIE_VV": phie, "NPHI_VV": nphi, "PHI_ND_VV": phi_nd,
            "RT_OHMM": rt, "SW_ARCHIE_VV": sw
        })
    return out
