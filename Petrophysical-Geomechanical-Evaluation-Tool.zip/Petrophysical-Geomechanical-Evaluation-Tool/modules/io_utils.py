import csv
import os

def read_csv(path):
    with open(path, "r", newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        if not reader.fieldnames:
            raise ValueError("Input CSV has no header row.")
        rows = []
        for raw in reader:
            row = {}
            for key, value in raw.items():
                if value is None or value.strip() == "":
                    row[key] = None
                else:
                    try:
                        row[key] = float(value)
                    except ValueError:
                        row[key] = value.strip()
            rows.append(row)
    return rows

def write_csv(path, rows, fieldnames=None):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    if fieldnames is None:
        fieldnames = list(rows[0].keys()) if rows else []
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({k: ("" if row.get(k) is None else row.get(k)) for k in fieldnames})

def safe_float(row, key):
    value = row.get(key)
    if isinstance(value, (int, float)):
        return float(value)
    return None

def clamp(value, low, high):
    return max(low, min(high, value))
