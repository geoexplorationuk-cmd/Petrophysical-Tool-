from .io_utils import safe_float

def evaluate(rows, rock_rows, cfg):
    out = []
    previous_depth = None
    sv_mpa = 0.0
    for row, rock in zip(rows, rock_rows):
        depth = safe_float(row, "DEPTH_M")
        rho = safe_float(rock, "DENSITY_KG_M3")
        vp = safe_float(rock, "VP_M_S")
        if depth is not None and rho is not None:
            if previous_depth is None:
                previous_depth = depth
            else:
                dz = max(0.0, depth - previous_depth)
                sv_mpa += rho * 9.80665 * dz / 1e6
                previous_depth = depth
        pp = (cfg["pore_pressure_gradient_mpa_per_km"] * depth / 1000.0
              if depth is not None else None)
        effective = sv_mpa - pp if pp is not None else None
        # Deliberately illustrative Vp-UCS proxy; not a validated universal correlation.
        ucs = max(0.0, cfg["ucs_vp_intercept_mpa"] +
                  cfg["ucs_vp_slope_mpa_per_kms"] * (vp/1000.0)
                  if vp is not None else 0.0) if vp is not None else None
        out.append({
            "DEPTH_M": depth, "SV_VERTICAL_MPA_EST": sv_mpa if rho is not None else None,
            "PP_MPA_ASSUMED": pp, "SIGMA_V_EFFECTIVE_MPA_PROXY": effective,
            "UCS_MPA_EMPIRICAL_PROXY": ucs,
            "GEOMECH_NOTE": "Screening proxy only; no Shmin/Shmax or calibrated pore-pressure model"
        })
    return out
