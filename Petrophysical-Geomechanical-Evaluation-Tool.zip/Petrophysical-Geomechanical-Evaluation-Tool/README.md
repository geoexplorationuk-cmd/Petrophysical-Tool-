# Petrophysical & Geomechanical Evaluation Tool

**CSS Project | Formation Evaluation | Rock Physics | Fluid Substitution | Geomechanics**

A lightweight Python reference workflow that reads well-log CSV data and produces:
- Log QA/QC flags and a QC summary
- Shale volume, density porosity, neutron-density porosity, and Archie water saturation
- Dynamic elastic properties and acoustic impedance
- Gassmann fluid-substitution scenarios (illustrative brine-to-gas replacement)
- First-pass geomechanical indicators (overburden estimate, effective stress proxy, UCS proxy)
- CSV tables and a plain-text interpretation report

> **Important:** This is an educational/research starter package, not a calibrated reservoir-engineering product. Outputs depend on input units, mineral/fluid assumptions, log quality, local calibration and stress/pore-pressure models. Do not use these estimates for drilling, completion, well-integrity or investment decisions without independent validation.

## 1. Requirements

- Python 3.9+
- Standard library only (no NumPy, pandas, SciPy or plotting dependencies)

## 2. Quick start

From this directory:

```bash
python main.py --input data/css_example_well.csv --output results
```

The script writes:
- `results/qc_log.csv`
- `results/petrophysics.csv`
- `results/rock_physics.csv`
- `results/fluid_substitution.csv`
- `results/geomechanics.csv`
- `results/report.txt`

Run the built-in checks:

```bash
python -m unittest discover -s tests -v
```

## 3. Input CSV schema

The included example is synthetic and uses the following columns:

| Column | Unit | Description |
|---|---:|---|
| `DEPTH_M` | m | Measured depth / vertical depth proxy |
| `GR_API` | API | Gamma ray |
| `RHOB_GCC` | g/cm³ | Bulk density |
| `NPHI_VV` | v/v | Neutron porosity, decimal |
| `DTCO_USFT` | µs/ft | Compressional slowness |
| `DTS_USFT` | µs/ft | Shear slowness |
| `RT_OHMM` | ohm·m | Deep resistivity |
| `CALI_IN` | in | Caliper |
| `PEF_B_E` | b/e | Photoelectric factor |

Rows are depth ordered. Blank cells are treated as missing values. `NPHI_VV` is expected as decimal fraction (e.g. 0.22), not percent.

## 4. Workflow and equations

### QA/QC
Range checks, missing-value checks, depth-order checks, caliper deviation and sonic plausibility checks are reported as flags. These are screening rules and should be adapted to tool specifications and borehole conditions.

### Petrophysics
- Linear GR shale-volume indicator: `VSH = clamp((GR - GR_clean)/(GR_shale - GR_clean), 0, 1)`
- Density porosity: `PHID = (RHOMA - RHOB)/(RHOMA - RHOF)`
- Effective porosity proxy: `PHIE = max(0, PHID - VSH * shale_porosity)`
- Archie water saturation: `SW = ((a * Rw)/(PHIE^m * Rt))^(1/n)`, clipped to [0, 1]

Default parameters are in `config.py`; they are generic example values, not universal constants.

### Rock physics
Slowness is converted to velocity using `V (m/s) = 304800 / DT (µs/ft)`. Isotropic dynamic moduli are calculated from density, Vp and Vs. Density input is converted from g/cm³ to kg/m³.

### Fluid substitution
A simplified Gassmann workflow estimates saturated bulk modulus from dry-frame bulk modulus and fluid bulk modulus. The example starts from a brine-saturated reference and substitutes a gas-like fluid. The shear modulus is held constant. This assumes a connected pore system and low-frequency Gassmann conditions.

### Geomechanics
The package calculates a simple vertical stress estimate by integrating bulk density and reports an effective-stress proxy using the configured pore-pressure gradient. UCS is a deliberately labelled empirical proxy based on Vp; replace it with a locally calibrated lithology-specific model. Horizontal stresses and fracture pressure are not calculated.

## 5. Project structure

```text
Petrophysical-Geomechanical-Evaluation-Tool/
├── README.md
├── main.py
├── config.py
├── requirements.txt
├── data/
│   └── css_example_well.csv
├── modules/
│   ├── __init__.py
│   ├── io_utils.py
│   ├── log_qc.py
│   ├── petrophysics.py
│   ├── rock_physics.py
│   ├── fluid_substitution.py
│   └── geomechanics.py
├── tests/
│   └── test_calculations.py
└── results/                 # generated on first run
```

## 6. Extending the package

1. Replace the synthetic CSV with a depth-matched well dataset.
2. Confirm units, environmental corrections and curve mnemonics.
3. Calibrate clean/shale GR endpoints, matrix/fluid density, Archie parameters and Rw.
4. Supply measured mineralogy, fluid PVT and pressure/temperature where available.
5. Calibrate elastic and UCS relationships against core, laboratory or field measurements.
6. Add uncertainty ranges and independent QC before seismic-model export.

## 7. Disclaimer

Synthetic data are generated solely to demonstrate the workflow. The model does not replace petrophysical interpretation, rock-physics calibration, geomechanical modelling, or professional review.


## 8. HTML tool presentation and hands-on guide

Open `docs/index.html` in any modern browser (no server or internet connection required). It presents the principal modules, workflow, CSV schema, hands-on exercises, configuration sensitivity checks, output files and engineering limitations. The page also includes a local CSV preview; selected files remain in the browser and are not uploaded.

