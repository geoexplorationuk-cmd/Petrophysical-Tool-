import argparse
import os
from config import CONFIG
from modules.io_utils import read_csv, write_csv
from modules.log_qc import run_qc
from modules.petrophysics import evaluate as petrophysics
from modules.rock_physics import calculate as rock_physics
from modules.fluid_substitution import gassmann_substitution
from modules.geomechanics import evaluate as geomechanics

def write_report(path, rows, qc_counts, pet, rock, fluid, geo):
    def mean(key, data):
        vals = [r[key] for r in data if isinstance(r.get(key), (int, float))]
        return sum(vals)/len(vals) if vals else None
    lines = [
        "PETROPHYSICAL & GEOMECHANICAL EVALUATION – CSS EXAMPLE",
        "="*58,
        f"Input rows: {len(rows)}",
        f"QC PASS: {qc_counts['PASS']} | REVIEW: {qc_counts['REVIEW']} | FAIL: {qc_counts['FAIL']}",
        "",
        "Mean interpreted indicators (valid values only):",
        f"  Vsh (v/v): {mean('VSH_VV', pet)}",
        f"  Effective porosity (v/v): {mean('PHIE_VV', pet)}",
        f"  Archie Sw (v/v): {mean('SW_ARCHIE_VV', pet)}",
        f"  Vp (m/s): {mean('VP_M_S', rock)}",
        f"  Vs (m/s): {mean('VS_M_S', rock)}",
        f"  Dynamic Young's modulus (GPa): {mean('YOUNG_MODULUS_GPA', rock)}",
        f"  Vp change after illustrative fluid substitution (%): {mean('DELTA_VP_PERCENT', fluid)}",
        f"  UCS empirical proxy (MPa): {mean('UCS_MPA_EMPIRICAL_PROXY', geo)}",
        "",
        "Interpretation and limitations:",
        "- Synthetic example data only; not a real well or field dataset.",
        "- Linear GR Vsh and density-derived porosity are simplified screening methods.",
        "- Archie requires clean, water-wet assumptions and calibrated a, m, n and Rw.",
        "- Dynamic moduli are derived from sonic and density logs; static values require calibration.",
        "- Gassmann assumes suitable low-frequency, homogeneous/isotropic porous-medium conditions.",
        "- Fluid substitution is illustrative; validate mineral modulus, porosity, saturation and PVT.",
        "- Vertical stress is integrated from density over measured depth as a TVD proxy.",
        "- Pore pressure is an assumed gradient; effective stress is a proxy, not a full stress model.",
        "- UCS is an empirical placeholder and must be calibrated to core/lithology.",
        "- No horizontal stress, fracture pressure, wellbore stability or completion design is provided.",
        "",
        "Review QC flags and calibration assumptions before using any output in seismic studies."
    ]
    with open(path, "w", encoding="utf-8") as f:
        f.write("\\n".join(lines) + "\\n")

def main():
    parser = argparse.ArgumentParser(description="CSS petrophysical and geomechanical evaluation example")
    parser.add_argument("--input", default="data/css_example_well.csv")
    parser.add_argument("--output", default="results")
    args = parser.parse_args()
    rows = read_csv(args.input)
    if not rows:
        raise SystemExit("Input CSV contains no data rows.")
    os.makedirs(args.output, exist_ok=True)
    qc, counts = run_qc(rows, CONFIG)
    pet = petrophysics(rows, CONFIG)
    rock = rock_physics(rows)
    fluid = gassmann_substitution(rock, pet, CONFIG)
    geo = geomechanics(rows, rock, CONFIG)
    write_csv(os.path.join(args.output, "qc_log.csv"), qc)
    write_csv(os.path.join(args.output, "petrophysics.csv"), pet)
    write_csv(os.path.join(args.output, "rock_physics.csv"), rock)
    write_csv(os.path.join(args.output, "fluid_substitution.csv"), fluid)
    write_csv(os.path.join(args.output, "geomechanics.csv"), geo)
    write_report(os.path.join(args.output, "report.txt"), rows, counts, pet, rock, fluid, geo)
    print(f"Processed {len(rows)} rows. QC PASS={counts['PASS']} REVIEW={counts['REVIEW']} FAIL={counts['FAIL']}")
    print(f"Results written to: {args.output}")

if __name__ == "__main__":
    main()
